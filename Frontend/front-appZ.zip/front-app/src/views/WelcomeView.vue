<script setup>
import Welcome from '@/components/Welcome.vue';

</script>

<template>
  <main>
    <Welcome />
  </main>
</template>