<template>
    <div>
      <h1>Welcome</h1>
      <button @click="registerUser">Register User</button>
      
      <table v-if="message">
        <thead>
          <tr>
            <th>Response Message</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{{ message }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import axios from 'axios';
  
  // Definišemo reaktivnu promenljivu za čuvanje poruke iz odgovora
  const message = ref('');

  // Funkcija za registraciju korisnika
  const registerUser = async () => {
    axios.post('http://localhost:19132/api/users/register', {
        Username: 'Stefan Jovanovic',
        Email: 'stefan@gmail.com',
        Password: '123',
        Role: 'Trainer'
      }).then(response=>{
        message.value = response.data;
        alert(message);
      });
    }
  </script>
  
  <style>
  table {
    width: 50%;
    margin-top: 20px;
    border-collapse: collapse;
  }
  
  th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
  }
  
  th {
    background-color: #f2f2f2;
  }
  </style>
  